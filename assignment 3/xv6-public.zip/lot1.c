#include "types.h"
#include "stat.h"
#include "user.h"

// Function to perform a time-consuming task
void time_consuming_task(int tickets) {
    int progress = 0;
    int i;
    while (progress < 100) {
        for (i = 0; i < 10000000; i++) {
            asm volatile("nop"); // A simple time-consuming loop
        }
        progress += 10;
        printf(1, "Process with tickets %d: Progress %d%%\n", tickets, progress);
    }
}

int main(void) {
    printf(1, "Scheduler Test: Lottery vs. Round Robin\n");

    // Create child processes with different numbers of tickets
    int num_tickets[] = {10, 50, 100};
    int num_processes = sizeof(num_tickets) / sizeof(num_tickets[0]);
    int i;

    for (i = 0; i < num_processes; i++) {
        int pid = fork();
        if (pid == 0) {
            int tickets = num_tickets[i]; // Use number of tickets as nice value
            chtickets(0, tickets); // Set the number of tickets
            time_consuming_task(tickets);
            exit();
        }
    }

    // Wait for all child processes to complete
    for (i = 0; i < num_processes; i++) {
        wait();
    }

    return 0;
}
