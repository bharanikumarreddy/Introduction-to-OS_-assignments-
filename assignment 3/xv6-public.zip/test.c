#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int main(int argc, char *argv[]) {
    int priority;
    
    
    if (argc != 2) {
        printf(2, "Usage: test_scheduler [type: -p: priority] [priority: 0-20]\n");
        exit();
    }

    
    priority = atoi(argv[1]);

    

    if (priority < 0 || priority > 20) {
        printf(2, "Invalid priority (0-20)!\n");
        exit();
    }

    int pid = fork();
    
    if (pid < 0) {
        printf(2, "Fork failed\n");
        exit();
    }

    if (pid == 0) {
        // Child process
        chpr(getpid(), priority);
        int i;
        for (i = 0; i < 5; i++) {
            printf(1, "Child is running with priority %d\n", priority);
            sleep(1); // Sleep for 1 second to give the scheduler time
        }
        exit();
    } else {
        // Parent process
        wait(); // Wait for the child to complete
    }
    
    exit();
}

