#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

static uint xorshift_state[4] = {12345, 67890, 13579, 24680}; // Initial seed values
static uint seed_counter = 0;

void xorshift_seed() {
    uint seed = uptime() + seed_counter; // Use uptime as part of the seed
    xorshift_state[0] = seed;
    xorshift_state[1] = seed ^ 12345;
    xorshift_state[2] = seed ^ 67890;
    xorshift_state[3] = seed ^ 13579;
    seed_counter++;
}

uint xorshift() {
    uint t = xorshift_state[0] ^ (xorshift_state[0] << 11);
    xorshift_state[0] = xorshift_state[1];
    xorshift_state[1] = xorshift_state[2];
    xorshift_state[2] = xorshift_state[3];
    xorshift_state[3] = (xorshift_state[3] ^ (xorshift_state[3] >> 19)) ^ (t ^ (t >> 8));
    return xorshift_state[3];
}

int random(int max) {
    if (max <= 0) {
        return 1;
    }

    xorshift_seed(); // Initialize XORShift state with a new seed based on uptime

    uint random_value = xorshift();

    int rand = random_value % max;

    if (rand < 0) {
        rand = -rand;
    }

    return rand;
}


#include "types.h"
#include "user.h"

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf(2, "Usage: %s <max>\n", argv[0]);
        exit();
    }

    int max = atoi(argv[1]);
    int i;
    for ( i = 0; i < 1000; i++) {
        xorshift_seed(); // Initialize XORShift state with a new seed based on uptime
        int result = random(max);
        printf(1, "%d\n",result);
    }

    exit();
}


