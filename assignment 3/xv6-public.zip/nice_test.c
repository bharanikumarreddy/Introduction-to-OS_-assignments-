#include "types.h"
#include "stat.h"
#include "user.h"

int main(void) {
    printf(1, "Nice Value Assignment Test\n");

    // Create a child process with an initial nice value
    int pid = fork();
    if (pid == 0) {
        // Assign a nice value within the valid range (0-20)
        int validPriority = 10;
        chpr(0, validPriority);
        printf(1, "Child Process: Assigned valid priority %d\n", validPriority);
        exit();
    } else if (pid < 0) {
        printf(2, "Fork failed\n");
        exit();
    }

    // Wait for the child process to complete
    wait();

    // Attempt to assign an out-of-bound priority value
    int outOfBoundPriority = 25;
    chpr(pid, outOfBoundPriority);
    printf(1, "Attempted to assign out-of-bound priority %d\n", outOfBoundPriority);

    exit();
}
