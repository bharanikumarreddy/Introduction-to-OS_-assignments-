#!/bin/bash

# Test Case 1: Valid inputs
echo "Test Case 1: Valid inputs"
./nice <PID> 10   # Replace <PID> with an actual process ID
if [ $? -eq 0 ]; then
    echo "Success: Priority changed to 10"
else
    echo "Failure: Priority change failed"
fi

# Test Case 2: Invalid priority
echo "Test Case 2: Invalid priority"
./nice <PID> 25   # Replace <PID> with an actual process ID
if [ $? -ne 0 ]; then
    echo "Success: Priority change failed (Invalid priority)"
else
    echo "Failure: Priority changed unexpectedly"
fi

# Test Case 3: Insufficient arguments
echo "Test Case 3: Insufficient arguments"
./nice <PID>      # Replace <PID> with an actual process ID
if [ $? -ne 0 ]; then
    echo "Success: Insufficient arguments handled"
else
    echo "Failure: Program should have detected insufficient arguments"
fi

