#include "types.h"
#include "stat.h"
#include "user.h"

// Function to perform a time-consuming task
void time_consuming_task(int tickets, int pid) {
    int progress = 0;
    int i;
    while (progress < 100) {
        for (i = 0; i < 10000000; i++) {
            asm volatile("nop"); // A simple time-consuming loop
        }
        progress += 10;
        printf(1, "Process with tickets %d (PID %d): Progress %d%%\n", tickets, pid, progress);
    }
}

int main(void) {
    printf(1, "Lottery Scheduler Test: Unfair Distribution of Tickets\n");

    // Create child processes with varying numbers of tickets (unfair distribution)
    int num_tickets[] = {10, 10, 90};
    int num_processes = sizeof(num_tickets) / sizeof(num_tickets[0]);
    int i;

    for (i = 0; i < num_processes; i++) {
        int pid = fork();
        if (pid == 0) {
            int tickets = num_tickets[i];
            chtickets(0, tickets);
            time_consuming_task(tickets, getpid()); // Pass the PID to the function
            exit();
        }
    }

    // Wait for all child processes to complete
    for (i = 0; i < num_processes; i++) {
        wait();
    }

    return 0;
}
