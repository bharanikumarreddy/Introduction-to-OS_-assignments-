#include "types.h"
#include "stat.h"
#include "user.h"

int main(void) {
    printf(1, "Lottery Scheduler Test: Dynamic Ticket Adjustment\n");

    // Create child processes with the same number of tickets initially
    int num_tickets = 50;
    int num_processes = 3;
    int i,j;

    for (i = 0; i < num_processes; i++) {
        int pid = fork();
        if (pid == 0) {
            int tickets = num_tickets;
            chtickets(0, tickets);
            int progress = 0;
            while (progress < 100) {
                // Adjust the number of tickets dynamically
                if (progress == 30) {
                    chtickets(0, 80); // Increase tickets
                    printf(1, "Process %d: Increased tickets to 80\n", getpid());
                    tickets = 80; // Update the current ticket value
                }
                if (progress == 60) {
                    chtickets(0, 20); // Decrease tickets
                    printf(1, "Process %d: Decreased tickets to 20\n", getpid());
                    tickets = 20; // Update the current ticket value
                }
                for ( j = 0; j < 10000000; j++) {
                    asm volatile("nop"); // A simple time-consuming loop
                }
                progress += 10;
                printf(1, "Process %d with %d tickets: Progress %d%%\n", getpid(), tickets, progress);
            }
            exit();
        }
    }

    // Wait for all child processes to complete
    for (i = 0; i < num_processes; i++) {
        wait();
    }

    return 0;
}
